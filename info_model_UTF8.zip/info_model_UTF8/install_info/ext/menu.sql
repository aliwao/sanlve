INSERT INTO `phpcms_menu` (`name`, `parentid`, `m`, `c`, `a`, `data`, `listorder`, `display`) VALUES
('info_setting', 977, 'admin', 'info', 'init', '', 0, '1');