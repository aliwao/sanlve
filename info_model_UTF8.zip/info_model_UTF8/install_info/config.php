<?php
return array(
				'steps'=>array('ext','version'),//本升级程序需要使用的升级步骤。
				'from_version'=>'V9.0.7',//需要升级的程序
				'from_release'=>'20110413',//需要升级的程序版本
				'modelname'=>'V9 信息模型',//安装的模型名称
				'version_check'=>'1',//是否对版本进行严格检查
				'version_description'=>'',//版本介绍	
);